#include <ntddk.h>

// 1. Unified IOCTL code
#define IOCTL_READ_MEMORY CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_ANY_ACCESS)

// 2. Command Enum (Must match Client exactly)
typedef enum _COMMAND_TYPE {
    COMMAND_NONE = 0,
    COMMAND_READ_MEMORY,
    COMMAND_WRITE_MEMORY,
    COMMAND_GET_BASE_ADDRESS
} COMMAND_TYPE;

// 3. Unified Struct (Must match Client exactly)
typedef struct _KERNEL_COMMAND_REQUEST {
    unsigned long ProcessId;
    unsigned __int64 Address;
    void* Buffer;
    unsigned __int64 Size;
    COMMAND_TYPE Command;
} KERNEL_COMMAND_REQUEST, * PKERNEL_COMMAND_REQUEST;

// Prototypes
NTKERNELAPI NTSTATUS NTAPI MmCopyVirtualMemory(PEPROCESS SourceProcess, PVOID SourceAddress, PEPROCESS TargetProcess, PVOID TargetAddress, SIZE_T BufferSize, KPROCESSOR_MODE PreviousMode, PSIZE_T ReturnSize);
NTKERNELAPI NTSTATUS PsLookupProcessByProcessId(HANDLE ProcessId, PEPROCESS* Process);

NTSTATUS IoControl(PDEVICE_OBJECT DeviceObject, PIRP Irp) {
    UNREFERENCED_PARAMETER(DeviceObject);
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
    NTSTATUS status = STATUS_SUCCESS;

    if (stack->Parameters.DeviceIoControl.IoControlCode == IOCTL_READ_MEMORY) {
        // Cast to our new Unified Struct
        PKERNEL_COMMAND_REQUEST request = (PKERNEL_COMMAND_REQUEST)Irp->AssociatedIrp.SystemBuffer;
        PEPROCESS targetProcess = NULL;

        if (request && NT_SUCCESS(PsLookupProcessByProcessId((HANDLE)(ULONG_PTR)request->ProcessId, &targetProcess))) {
            size_t bytes;

            // Handle based on the Command sent by Client
            switch (request->Command) {
            case COMMAND_READ_MEMORY:
                MmCopyVirtualMemory(
                    targetProcess,
                    (PVOID)request->Address,
                    PsGetCurrentProcess(),
                    request->Buffer,
                    (SIZE_T)request->Size,
                    KernelMode,
                    &bytes
                );
                break;

            case COMMAND_WRITE_MEMORY:
                MmCopyVirtualMemory(
                    PsGetCurrentProcess(),
                    request->Buffer,
                    targetProcess,
                    (PVOID)request->Address,
                    (SIZE_T)request->Size,
                    KernelMode,
                    &bytes
                );
                break;

            default:
                status = STATUS_INVALID_PARAMETER;
                break;
            }
            ObDereferenceObject(targetProcess);
        }
    }

    Irp->IoStatus.Status = status;
    Irp->IoStatus.Information = sizeof(KERNEL_COMMAND_REQUEST);
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return status;
}

NTSTATUS CreateClose(PDEVICE_OBJECT DeviceObject, PIRP Irp) {
    UNREFERENCED_PARAMETER(DeviceObject);
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}

// 4. Driver Entry
NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
    UNREFERENCED_PARAMETER(RegistryPath);

    // Safety check for kdmapper
    if (!DriverObject) return STATUS_SUCCESS;

    UNICODE_STRING devName, symName;
    RtlInitUnicodeString(&devName, L"\\Device\\FinalFix_01");
    RtlInitUnicodeString(&symName, L"\\DosDevices\\Global\\FinalFix_01");

    PDEVICE_OBJECT DeviceObject = NULL;
    NTSTATUS status = IoCreateDevice(DriverObject, 0, &devName, FILE_DEVICE_UNKNOWN, FILE_DEVICE_SECURE_OPEN, FALSE, &DeviceObject);

    if (NT_SUCCESS(status)) {
        IoCreateSymbolicLink(&symName, &devName);

        DriverObject->MajorFunction[IRP_MJ_CREATE] = CreateClose;
        DriverObject->MajorFunction[IRP_MJ_CLOSE] = CreateClose;
        DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = IoControl;

        DeviceObject->Flags |= DO_BUFFERED_IO;
        DeviceObject->Flags &= ~DO_DEVICE_INITIALIZING;
    }

    return status;
}